using System;

namespace WAREHOUSE_MANAGEMENT_SYSTEM.Models
{
    public class ErrorViewModel
    {
        public string RequestId { get; set; }

        public bool ShowRequestId => !string.IsNullOrEmpty(RequestId);
    }
}
