# web-server-languages-uni-project
Warehouse management system with Asp .NET Core
